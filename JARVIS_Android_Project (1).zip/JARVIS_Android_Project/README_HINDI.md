# JARVIS Android

यह Android starter project voice commands सुनकर YouTube, Chrome/Google, Camera, Settings और Home खोल सकता है और समय बता सकता है।

## चलाने का तरीका
1. Android Studio में project खोलें।
2. Gradle Sync पूरा होने दें।
3. फोन connect करके Run दबाएँ।
4. Microphone permission Allow करें।
5. “JARVIS सुनो” दबाकर command बोलें।

उदाहरण:
- YouTube खोलो
- Chrome खोलो
- Camera खोलो
- Settings खोलो
- Home पर जाओ
- समय बताओ

यह starter version PIN/Pattern/Password bypass नहीं करता और screen lock को अपने-आप नहीं हटाता।
