package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView status; SpeechRecognizer recognizer; TextToSpeech tts;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button listen = findViewById(R.id.listenButton);

        tts = new TextToSpeech(this, s -> {});
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);

        listen.setOnClickListener(v -> listen());
    }

    void listen() {
        status.setText("सुन रहा हूँ...");
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onResults(Bundle r) {
                ArrayList<String> x = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (x != null && !x.isEmpty()) handleCommand(x.get(0).toLowerCase(Locale.ROOT));
                recognizer.destroy();
            }
            public void onError(int e) { status.setText("फिर से बोलिए"); recognizer.destroy(); }
            public void onReadyForSpeech(Bundle p) {} public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {} public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {} public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        recognizer.startListening(i);
    }

    void handleCommand(String c) {
        status.setText("आपने कहा: " + c);
        if (c.contains("youtube")) open("https://www.youtube.com");
        else if (c.contains("chrome")) open("https://www.google.com");
        else if (c.contains("camera")) {
            try { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
            catch(Exception e) { speak("कैमरा नहीं खुल सका"); }
        } else if (c.contains("settings")) startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
        else if (c.contains("home")) startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
        else if (c.contains("समय") || c.contains("time")) speak(new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()));
        else speak("कमांड समझ नहीं आई");
    }

    void open(String url) { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))); }
    void speak(String s) { status.setText(s); if(tts!=null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis"); }
}
